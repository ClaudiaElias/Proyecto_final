/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package labgrupo;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Roger Mendez
 */
public class LabGrupo {

   
    private static final int PARED = 0;
    private static final int CAMINO = 1;
    private static final int VISITADO = 2;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el tamaño del laberinto (n): ");
        int n = scanner.nextInt();

        int[][] laberinto = generarLaberinto(n);

      

        // Elegir puntos inicial y final
        int[] puntoInicial = elegirPunto("Ingrese las coordenadas del punto inicial (fila columna): ", scanner, n);
        int[] puntoFinal = elegirPunto("Ingrese las coordenadas del punto final (fila columna): ", scanner, n);

        // Encontrar y mostrar el camino
        encontrarCamino(laberinto, puntoInicial[0], puntoInicial[1], puntoFinal[0], puntoFinal[1]);
        System.out.println("\nLaberinto con camino:");
        mostrarLaberinto(laberinto);

        scanner.close();
    }

    private static int[] elegirPunto(String mensaje, Scanner scanner, int n) {
        System.out.print(mensaje);
        int[] punto = new int[2];
        punto[0] = scanner.nextInt();

        while (punto[0] < 0 || punto[0] >= n) {
            System.out.println("La fila debe estar entre 0 y " + (n - 1) + ". Inténtelo de nuevo.");
            System.out.print("Ingrese la fila: ");
            punto[0] = scanner.nextInt();
        }

        punto[1] = scanner.nextInt();

        while (punto[1] < 0 || punto[1] >= n) {
            System.out.println("La columna debe estar entre 0 y " + (n - 1) + ". Inténtelo de nuevo.");
            System.out.print("Ingrese la columna: ");
            punto[1] = scanner.nextInt();
        }

        return punto;
    }

    private static int[][] generarLaberinto(int n) {
        int[][] laberinto = new int[n][n];
        Random rand = new Random();

        // Llenar el laberinto con paredes
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                laberinto[i][j] = PARED; 
            }
        }

        // Generar un camino aleatorio desde la fila superior hasta la fila inferior
        int filaActual = 0;
        int columnaActual = rand.nextInt(n);
        laberinto[filaActual][columnaActual] = CAMINO;

        while (filaActual < n - 1) {
            int direccion = rand.nextInt(3) - 1; // -1, 0, 1
            columnaActual += direccion;

            // Asegurarse de que la columna esté dentro de los límites
            columnaActual = Math.max(0, Math.min(n - 1, columnaActual));

            // Marcar el camino
            laberinto[++filaActual][columnaActual] = CAMINO;
        }

        return laberinto;
    }

    private static void mostrarLaberinto(int[][] laberinto) {
        for (int[] fila : laberinto) {
            for (int celda : fila) {
                System.out.print(celda + " ");
            }
            System.out.println();
        }
    }

    private static boolean encontrarCamino(int[][] laberinto, int x, int y, int xFinal, int yFinal) {
        // Caso base: llegar al punto final
        if (x == xFinal && y == yFinal) {
            laberinto[x][y] = CAMINO;
            return true;
        }

        // Verificar si la posición actual es válida
        if (esPosicionValida(laberinto, x, y)) {
            // Marcar la posición actual como visitada
            laberinto[x][y] = VISITADO;

            // Intentar moverse en todas las direcciones posibles
            if (encontrarCamino(laberinto, x + 1, y, xFinal, yFinal) ||
                    encontrarCamino(laberinto, x - 1, y, xFinal, yFinal) ||
                    encontrarCamino(laberinto, x, y + 1, xFinal, yFinal) ||
                    encontrarCamino(laberinto, x, y - 1, xFinal, yFinal)) {
                laberinto[x][y] = CAMINO;
                return true;
            }
        }

        return false;
    }

    private static boolean esPosicionValida(int[][] laberinto, int x, int y) {
        int n = laberinto.length;
        return x >= 0 && x < n && y >= 0 && y < n && (laberinto[x][y] == CAMINO || laberinto[x][y] == PARED);
    }
    
}
